#include <iostream>
#include <iomanip>
#include <cmath>
//(137368) Victor Mwendwa Muasya

using namespace std;

int main ()
{
    
float s1, s2, s3;
float perim, area, p;
float answer;
int choice;
int y, n;
bool running = true;


cout << "Triangle Calculator";


do
{

cout << "\n\nEnter the Base side: ";
cin >> s1;

cout << "Enter the Height side: ";
cin >> s2;

cout << "Enter the Hypothunse side: ";
cin >> s3;
    
perim = s1 + s2 + s3;
p=.5*perim;

if (perim<=0)
cout << "Not a triangle";



else

area=sqrt(p *(p - s1)*(p - s2)*(p - s3));

cout << "\nThe perimeter is " << perim << endl;
cout << "The area is " << area << endl;
}



while (running );


cout << "Another? (y/n)";
cin >> choice;

return 0;
}

