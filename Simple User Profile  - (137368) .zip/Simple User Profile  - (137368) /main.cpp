//
//  main.cpp
//  Simple User Profile
//
//  Created by Vector Mwendwa on 10/26/21.
//
#include <iostream>
using namespace std;

struct student
{
    char fname[50];
    char lname[50];
    char meal [50];
    char movie [50];
};

int main()
{
    student s;
    cout << "Enter information," << endl;
    cout << "Enter first Name: ";
    cin >> s.fname;
    cout << "Enter last Name: ";
    cin >> s.lname;
    cout << "Whats your favorite meal ? ";
    cin >> s.meal;
    cout << "Whats your favorite movie ? ";
    cin >> s.movie;

    cout << "\nDisplaying Information," << endl;
    cout << "Name: " << s.fname << " ";
    cout << s.lname<<endl;
    cout << "Favorite Meal: " << s.meal << endl;
    cout << "Favorite Movie: " << s.movie << endl;
    return 0;
}
