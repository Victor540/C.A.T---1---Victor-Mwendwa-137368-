// C.A.T 1
//  main.cpp
//  Question 2 - Write a C++ program that takes in temperature in Fahrenheit and converts it to Celsius
//
//  Created by 137368 - Vector Mwendwa on 11/9/21.
//
#include <iostream>
double fahrenheitToCelsius(double fahrenheit)
 {
     double celsius;
 //  The Formula that converts Celsius to Fahrenheit
     celsius = (fahrenheit - 32.0) * 5.0 / 9.0;
     return celsius;
 }
 
 int main()
 {
     double fahrenheit;
 // Enter Temperature Values
     std::cout << "Enter Temperature in Fahrenheit = ";
     std::cin  >> fahrenheit;
     std::cout << "The Temperature in Celsius is = "
               << fahrenheitToCelsius(fahrenheit) << std::endl;
 }
