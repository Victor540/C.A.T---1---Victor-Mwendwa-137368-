//
//  main.cpp
///
//Using a do....while loop write a program that calculates the sum of intergers input by a user. The program should allow the user to enter as many numbers as possible, until the user enters 0.
//
//  Created by Victor Mwendwa 137368 on 11/16/21.
//
#include <iostream>
using namespace std;
int main ()
{
    int num; // Declare and inialize varibale
    int sum = 0;
    do
    {
        cout << "Enter a valid number to see the sum. Enter 0 to stop: /n";
        cin >> num;
        sum += num;
        
    } while (num !=0);
    cout << "sum is of entered number is : "<< sum<<endl; // Output when user enters a O to end the loop
    return 0;
}
