//
//  main.cpp
//  do...while loop -Task 1
// Using a do....while loop, write a program that outputs the even numbers from 12 to 50.
//
//  Created by Victor Mwendwa 137368 on 11/18/21.
//

#include <iostream>
using namespace std;

int main(){
    //Initialize  x with the value 12
    int x=12;
    do{
    //If the number is divisible by 2 then print in the console
    if (x % 2 == 0){
        std::cout<< x << "\n";
    }
    //Increment the value x
    x++;
    }
    //If x is less than or equal to 50
    while(x<=50);
    return 0;
}
