//
//  main.cpp
//  do....while loop - Task 2
// Using a do..while loop write a progra to compute the sum of numbers between 20 and 25.
//
//  Created by Victor Mwendwa Muasya  on 11/18/21.
//

#include <iostream>
using namespace std;

int main(){
    //Initialize x and i with the values 20 and 0 respectively, X is our counter and I is our sum.
    int x = 20;
    int i = 0;
    //The do statement.
    do{
        i += x;
    //Increment the value X.
        x++;
    }
    //If x is less than or equal to 25
    while(x<=25);
    std::cout<<"The sum of values between 20 and 25 is : "<<i;
    return 0;
}
