//
//  main.cpp
//  Type Casting
//
//  Created by (137368) Vector Mwendwa on 10/19/21.
//
#include <iostream>
using namespace std;

int main(){

double myNum =  15.5;
int myNewNum;
myNewNum = myNum;

cout<<"myNewNum value is : "<<myNewNum<<"\n";

//Boolean datatype
    cout<<"implicit type of casting of an integer type to a boolean type\n";
bool nottrue = 0;
bool True = 7;
cout<<"the False result is : "<<nottrue<<endl;
cout<<"the True result is : "<<True<<endl;

//Characters, Integers and Floating Values
char mychar;
int myint = 45;
float myfloat = 4.567;
int mynum2;
    mychar = static_cast<char>(myint);
    mynum2 = static_cast<int>(myfloat);
cout<<"---Typecasting character values, integers, and float....\n";
cout<<"mychar is : "<<mychar<<endl;
cout<<"mynum2 is : "<<mynum2<<endl;

return 0;

}


