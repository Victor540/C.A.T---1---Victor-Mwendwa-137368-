//
// If and Else Statements tasks
// 137368 - Victor Mwendwa Muasya



#include<iostream>
using namespace std;


int main(){
int age;

cout<<"Please Enter Age : ";
    cin>>age;
cout<<"\n";

if(age>=4){

cout<<"Admitted, proceed to Registration.";     }
else{
cout<<"Declined, Age is not Permitted.\n";     }

    return 0;

}
