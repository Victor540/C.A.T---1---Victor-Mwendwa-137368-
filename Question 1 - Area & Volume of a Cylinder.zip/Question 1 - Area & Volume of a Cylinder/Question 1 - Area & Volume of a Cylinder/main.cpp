// C.A.T 1
//  main.cpp
//  Question 1 - Write a C++ program that is able to correctly calculate the area and volume of any cylinder and display them to the user.
//
//  Created by 137368 - Vector Mwendwa on 11/9/21.
//
//using namespace std;
//
#include <iostream>
using namespace std;
const double PI = 3.141592;
// Cylinder Volume
double calcVolume(double R, double h)
{
 return PI*R*R*h;
}
// Cylinder Area
double calcArea(double R, double h)
{
 return 2*PI*R*(h + R);
}
// Enter Numerical Values
void promptValues(double &h, double &R)
{
 cout << "Enter Cylinder radius: ";
 double RT;
 cin >> RT;
 cout << "Enter Cylinder height: ";
 double hT;
 cin >> hT;
 R = RT;
 h = hT;
}
//
void calcValues(double h, double R)
{
 cout << "Volume of this Cylinder is: " << calcVolume(R, h) << endl;
 cout << "Area of this Cylinder is: " << calcArea(R, h) << endl;
}
//
int main()
{
 double R, h;
 promptValues(h, R);
 calcValues(h, R);
 return 0;
}
