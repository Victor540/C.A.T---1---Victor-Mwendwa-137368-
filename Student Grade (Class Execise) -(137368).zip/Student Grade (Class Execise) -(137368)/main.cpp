//
//  main.cpp
//  Student Grade (Class Execise)
//
//  Created by Vector Mwendwa on 11/2/21.
//
#include<iostream>
using namespace std;
int main()
{
   // variables
   int score;
   char grade;
    string name;
   // take score
   cout << "Enter Student's Name: ";
    getline(cin, name);
   cout << "Enter Student's Score(0-100): ";
   cin >> score;
   // check score is valid or not
   // score is valid if it belongs to 0-100
   if(score<0 || score>100)
   {
     cout << "Invalid Score" << endl;
     return 0; // stop execution
   }

   // find grade using switch-case
   switch(score/10)
   {
     case 10:
     case 9:
     cout<<name;
       grade = 'A';
       cout<<" ";
       break;
     case 8:
         cout<<name;
       grade = 'B';
       cout<<" ";
       break;
     case 7:
         cout<<name;
         cout<<" ";
       grade = 'C';
       break;
     case 6:
         cout<<name;
         cout<<" ";
       grade = 'D';
       break;
     case 5:
         cout<<name;
         cout<<" ";
       grade = 'E';
       break;
     default:
         cout<<name;
     cout<<" ";
       grade = 'F';
   }

   // display grade
   cout << "Grade = " << grade << endl;

   return 0;
}
