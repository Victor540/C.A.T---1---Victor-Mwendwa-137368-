// C.A.T 1
//  main.cpp
//  Question 3 - Write a C++ program that calculates the tax payable to the government and net salary (amount after tax deductions) of an employee based on the new tax rate and display it to the screen.
//
//  Created by 137368 - Vector Mwendwa on 11/9/21.
//
#include<iostream>
using namespace std;
double calcTax(double);
double averageTaxRate(double,double);
//
int main (){
double salary;
double totalTax;
double taxRate;
//
cout<<"Enter your gross salary: "<<endl;
cin>>salary;
totalTax= calcTax(salary);//function call
taxRate= averageTaxRate(salary,totalTax);//function call
cout<<"Tax Payable: "<<totalTax<<endl;
cout<<"Average Tax Rate Is :"<<taxRate<<endl;
return 0;// end of main function
}
 //****** function definitions***
double calcTax(double pay){ // function header
    double taxableInc;
    double totalTax;
    
