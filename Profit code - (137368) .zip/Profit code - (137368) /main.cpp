# include <iostream>
//Victor Mnwendwa Muasya (137368)
using namespace std;
int main()
{
    int cp,sp,profit, loss;
    cout <<"Enter Buying price: (Kshs.)"<<endl;
    cin>>cp;
    cout <<"Enter selling price: (Kshs.)"<<endl;
    cin>>sp;
    if(sp>cp)
    {
        profit=sp-cp;
        cout<<"profit"<<profit<<endl;
    }
    else if(cp>sp)
{
    loss=cp-sp;
    cout<<" Loss of "<<loss<<endl;
}
else
{
    cout<<"no profit no loss.";
}
}
