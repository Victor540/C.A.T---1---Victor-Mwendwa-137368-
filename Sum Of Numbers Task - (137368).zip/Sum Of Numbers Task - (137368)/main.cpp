

// Sum Of Numbers Tasks - Date - 10-24-2021
// Victor Mwendwa Muasya -137368


#include <iostream>
using namespace std;

int main(){
    int num1;
    int num2;
    cout << "The sum of two  numbers inputted by users:\n";
    cout << "-------------------------------------------\n";
    cout << "Kindly input the first number:";
    cin >> num1;
    cout << "\n\n";
    cout << "Kindly input the second number:";
    cin >> num2;
    cout << "\n\n";
    cout << "-------------------------------------------\n\n";
    cout <<"The sum of the two numbers is : "<< num1+num2;
    cout <<"\n\n";
    
    return 0;
}
